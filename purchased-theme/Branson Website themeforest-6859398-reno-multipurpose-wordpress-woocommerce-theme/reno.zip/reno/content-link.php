<?php
/**
 * The default template for displaying content. Used for both single and index/archive/search.
 */
?>

<div class="blog-container"> <!-- blog container -->                        
  <!-- Blog slider flexslider -->
  <div class="center-nav-content-slider">
    <?php the_post_thumbnail('listing'); ?>
  </div>   
  <!-- Blog slider flexslider end -->  
  <div class="blog-title-2">        
    <i class="fa fa-file-text-o icon-2x"></i> 
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><span class="blog-date"><?php echo get_the_date(); ?></span></h3>
    <h5><?php echo reno_show_category_links($post->ID); ?> - By: <?php echo get_the_author(); ?></h5>
   </div>
  <div class="blog-text">
    <?php the_content(); ?>
    <a href="<?php the_permalink(); ?>" class="btn btn-small pull-right margin-0"><?php _('Read more', 'reno'); ?></a>
  </div>
</div><!-- blog container end -->