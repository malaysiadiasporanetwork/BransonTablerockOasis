<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each specific one. For example, reno already
 * has tag.php for Tag archives, category.php for Category archives, and
 * author.php for Author archives.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 */

get_header(); ?>

	<div class="container">
	

		<?php if ( have_posts() ) : ?>
			<div class="spacer40"></div>
			<h3 class="archive-title"><?php
				if ( is_day() ) :
					printf( __( 'Daily Archives: %s', 'reno' ), '<span>' . get_the_date() . '</span>' );
				elseif ( is_month() ) :
					printf( __( 'Monthly Archives: %s', 'reno' ), '<span>' . get_the_date( _x( 'F Y', 'monthly archives date format', 'reno' ) ) . '</span>' );
				elseif ( is_year() ) :
					printf( __( 'Yearly Archives: %s', 'reno' ), '<span>' . get_the_date( _x( 'Y', 'yearly archives date format', 'reno' ) ) . '</span>' );
				else :
					_e( 'Archives', 'reno' );
				endif;
			?></h3>
			<div class="spacer20"></div>
			<?php
			if($entiri_opt['blog-template'] == 'left_sidebar' || (isset($_GET['template']) && $_GET['template'] == 'left_sidebar')) { 
				load_template(TEMPLATEPATH . '/blog-left_sidebar.php');
			}
			
			elseif ($entiri_opt['blog-template'] == 'full_width'  || (isset($_GET['template']) && $_GET['template'] == 'full_width')) {
				load_template(TEMPLATEPATH . '/blog-full_width.php');
			}
			elseif ($entiri_opt['blog-template'] == 'right_sidebar'  || (isset($_GET['template']) && $_GET['template'] == 'right_sidebar')) {
				load_template(TEMPLATEPATH . '/blog-right_sidebar.php');
			}
			?>
			<?php 
				reno_content_nav( 'nav-below' );	
			?>

			<?php else : ?>
				<?php get_template_part( 'content', 'none' ); ?>
			<?php endif; ?>

			
		
	
	</div>


<?php get_footer(); ?>