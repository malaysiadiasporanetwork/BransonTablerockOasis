<?php
/**
 * The default template for displaying content. Used for both single and index/archive/search.
 */
?>
<div class="blog-container"> <!-- blog container -->                        
  <!-- Blog slider flexslider -->
  
   <?php the_post_thumbnail('listing'); ?>
  
  <!-- Blog slider flexslider end -->  
  <div class="blog-title-2">        
    <i class="fa fa-file-text-o icon-2x"></i> 
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><span class="blog-date"><?php echo get_the_date(); ?></span></h3>
    <h5><?php echo reno_show_category_links($post->ID); ?> - By: <?php echo get_the_author(); ?></h5>
   </div>
  <div class="blog-text">
    <?php the_content(); ?>
    <?php if(!is_single()) { ?>
        <a href="<?php the_permalink(); ?>" class="btn btn-small pull-right margin-0"><?php _e('Read more', 'reno'); ?></a>
    <?php } ?>
  </div>
</div><!-- blog container end -->
<?php if(!is_single()) { ?>
  <hr class="medium-line">
<?php } else { ?>
 
    <div class="blog-container-pagging"> <!-- blog container -->
        <div class="blog-container-blog-list">
          <a href="<?php echo get_permalink( get_option('page_for_posts' ) ); ?>"><i class="fa fa-angle-left"></i> <?php printf( __('Back to blog list', 'ypsilon')); ?></a> 
        </div>
        <div class="blog-container-pagging-next">
          <?php next_post_link('%link', '<i class="fa fa-angle-right"></i>'); ?>
        </div>      
        <div class="blog-container-pagging-prev">
          <?php previous_post_link('%link', '<i class="fa fa-angle-left"></i>'); ?>
        </div>
    </div>

    <?php if (comments_open($post->ID)){ ?>
        <?php comments_template( '', true ); ?>
    <?php } ?>

<?php } ?>



