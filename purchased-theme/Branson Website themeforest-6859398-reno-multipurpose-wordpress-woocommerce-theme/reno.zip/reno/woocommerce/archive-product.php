<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive.
 *
 * Override this template by copying it to yourtheme/woocommerce/archive-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce_loop;
global $entiri_opt;

get_header('shop'); ?>

	<div class="container">

	<?php
		/**
		 * woocommerce_before_main_content hook
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */
		
	?>	
		
			<?php //if ( apply_filters( 'woocommerce_show_page_title', true ) ) { ?>

			<?php if($entiri_opt['shop_show_heading'] == 1) { ?>
				<div class="row spacer40"></div>
				<div class="row">
					<div class="col-md-7">
						<h3 class="page-title"><?php woocommerce_page_title(); ?></h3>
					</div>
					<div class="col-md-5">
						<?php do_action('woocommerce_before_main_content'); ?>
					</div>
				</div>
				<div class="row spacer20"></div>
			<?php } else {
				do_action('woocommerce_before_main_content');
			} ?>

		

		<?php do_action( 'woocommerce_archive_description' ); ?>

		<?php if ( have_posts() ) : ?>

			<?php if($entiri_opt['shop_show_filter'] == 1) { ?>
				<div class="row">
			      <div class="col-md-12">
			        <ul id="shop-filter">
			          <li <?php if((isset($_GET['orderby']) && $_GET['orderby']=='menu_order') || (!isset($_GET['orderby']))) echo 'class="act"'; ?>><a href="?orderby=menu_order<?php if (isset($_GET['template'])) echo '&template=2'; ?>" class="filter" data-filter="*">All</a></li>
			          <li <?php if (isset($_GET['orderby']) && $_GET['orderby']=='popularity') echo 'class="act"'; ?>><a href="?orderby=popularity<?php if (isset($_GET['template'])) echo '&template=2'; ?>" class="filter" data-filter=".popularity">Popularity</a></li>
			          <li <?php if (isset($_GET['orderby']) && $_GET['orderby']=='rating') echo 'class="act"'; ?>><a href="?orderby=rating<?php if (isset($_GET['template'])) echo '&template=2'; ?>" class="filter" data-filter=".rating">Rating</a></li>
			          <li <?php if (isset($_GET['orderby']) && $_GET['orderby']=='price') echo 'class="act"'; ?>><a href="?orderby=price<?php if (isset($_GET['template'])) echo '&template=2'; ?>" class="filter" data-filter=".price">Price</a></li>
			        </ul>
			      </div>
			    </div>
			<?php } ?>

			<?php woocommerce_product_loop_start(); ?>

				<?php woocommerce_product_subcategories(); ?>	

				<div class="row">
					<?php

					if ( empty( $woocommerce_loop['columns'] ) )
						$woocommerce_loop['columns'] = 3;

					if ($entiri_opt['shop-layout'] == 'left_sidebar' && !isset($_GET['template'])) { ?>
						<div class="col-md-3 sidebar sidebar-shop">
							<?php //do_action('woocommerce_sidebar'); 
							dynamic_sidebar('shop');
							?>
						</div>
						<div class="col-md-9">

							<section class="row product-list">

								
								<?php while ( have_posts() ) : the_post(); ?>

									<?php woocommerce_get_template_part( 'content', 'product' ); ?>

								<?php endwhile; // end of the loop. ?>
								

							</section>
						</div>
					<?php
					}
					if ($entiri_opt['shop-layout'] == 'right_sidebar' || (isset($_GET['template']) && $_GET['template'] == 'right_sidebar')) { ?>
						<div class="col-md-9">
							<section class="row product-list">
								
								<?php while ( have_posts() ) : the_post(); ?>

									<?php woocommerce_get_template_part( 'content', 'product' ); ?>

								<?php endwhile; // end of the loop. ?>
								
							</section>
						</div>
						<div class="col-md-3 sidebar sidebar-shop">
							<?php dynamic_sidebar('shop'); ?>
						</div>	
					<?php
					}
					?>
					<?php if ($entiri_opt['shop-layout'] == 'full_width' || (isset($_GET['template']) && $_GET['template'] == 'full_width')) { ?>
						<div class="col-md-12">
							<section class="row product-list">
								
								<?php while ( have_posts() ) : the_post(); ?>

									<?php woocommerce_get_template_part( 'content', 'product' ); ?>

								<?php endwhile; // end of the loop. ?>
								
							</section>
						</div>

					<?php } ?>
				</div>
				<?php
				if($entiri_opt['shop_show_clients'] == 1) { ?>
					<h4><?php _e('Brands', 'reno'); ?></h4>
					<div class="owl-carousel carousel-top-navigation">           
	            
			            <?php 
			          	$loop = new WP_Query( array( 'post_type' => 'client', 'posts_per_page' => -1 ) );
					  	while ( $loop->have_posts() ) : $loop->the_post();
				          	$id_post = $loop->post->ID;
				          	?>
				          	<div class="item"> 
				                <a href="<?php echo get_post_meta($id_post, 'reno_client_link', true); ?>"><?php the_post_thumbnail( 'client', array('class' => 'brand') ); ?></a>                 
				            </div>   
				          	<?php
				        endwhile; 
				        wp_reset_query();
			          	?>                                                                                                                                                                   
			        </div>
			    <?php } ?>

			<?php woocommerce_product_loop_end(); ?>

			<?php
				/**
				 * woocommerce_after_shop_loop hook
				 *
				 * @hooked woocommerce_pagination - 10
				 */
				do_action( 'woocommerce_after_shop_loop' );
			?>

		<?php elseif ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) : ?>

			<?php woocommerce_get_template( 'loop/no-products-found.php' ); ?>

		<?php endif; ?>

	<?php
		/**
		 * woocommerce_after_main_content hook
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
		//do_action('woocommerce_after_main_content');
	?>

	<?php
		/**
		 * woocommerce_sidebar hook
		 *
		 * @hooked woocommerce_get_sidebar - 10
		 */
		
	?>
	</div>
<?php get_footer('shop'); ?>