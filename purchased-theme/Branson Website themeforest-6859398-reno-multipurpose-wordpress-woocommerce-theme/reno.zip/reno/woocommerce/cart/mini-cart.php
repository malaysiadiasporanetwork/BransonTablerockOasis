<?php
/**
 * Mini-cart
 *
 * Contains the markup for the mini-cart, used by the cart widget
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

global $woocommerce;
?>

<?php if ( sizeof( $woocommerce->cart->get_cart() ) > 0 ) { 

	$count = sizeof( $woocommerce->cart->get_cart() );
	if ($count == 1) { $string = "item"; }
	if ($count > 1) { $string = "items"; }
	$subtotal = $woocommerce->cart->get_cart_subtotal();
?>

<?php } ?>


<div class="shop-cart-header">
  <div class="shop-cart-header-logo"><a href="<?php echo $woocommerce->cart->get_cart_url(); ?>"><i class="fa fa-shopping-cart"></i></a></div>
  <?php if ( sizeof( $woocommerce->cart->get_cart() ) > 0 ) { ?>
  	  <div class="shop-cart-header-text"><?php echo $subtotal; ?><br>
  	  <span class="shop-cart-header-text-2"><?php echo $count. " ". $string; ?></span></div>
  <?php } else { ?>
  	  <div class="shop-cart-header-text"><?php _e('empty', 'reno'); ?></div>
  <?php } ?>
</div> 
