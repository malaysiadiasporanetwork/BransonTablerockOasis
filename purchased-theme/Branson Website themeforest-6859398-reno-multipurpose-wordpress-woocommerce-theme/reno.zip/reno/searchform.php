<form role="search" method="get" action="<?php echo home_url( '/' ); ?>">
<div class="input-group">
	
	      <input type="text" name="s" class="form-control" placeholder="Search">
	      <span class="input-group-btn">
		        <button class="btn searchsubmit" type="submit"><i class="fa fa-search"></i></button>
		  </span>
	
</div>
</form>