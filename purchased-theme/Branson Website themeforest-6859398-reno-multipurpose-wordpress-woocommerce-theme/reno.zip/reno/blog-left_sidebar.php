<?php
?>


    <div class="row">
        <div class="col-md-3">
            <?php get_sidebar(); ?>
        </div>
        <div class="col-md-9">
          <?php if ( have_posts() ) : ?>
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php get_template_part( 'content', get_post_format() ); ?>
                <?php endwhile; // end of the loop. ?>
            <?php else : ?>

                <p><?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'reno' ); ?></p>
                <?php get_search_form(); ?>

            <?php endif; ?>
        </div>
        
    </div>

