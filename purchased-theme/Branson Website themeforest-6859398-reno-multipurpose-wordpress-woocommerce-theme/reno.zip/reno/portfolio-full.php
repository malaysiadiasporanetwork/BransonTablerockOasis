<?php
global $entiri_opt;
?>



	<?php the_content(); ?>

<div class="row spacer80"></div>

				
				