<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 */

get_header(); ?>

	
	<?php while ( have_posts() ) : the_post(); ?>
		<?php if(get_post_meta($post->ID,'show_heading',true) == 'yes' || get_post_meta($post->ID,'show_breadcrumb',true) == 'yes') { ?>
			<div class="row spacer40"></div>
		<?php } ?>
		<div class="container">
			<div class="row">
			<?php if(get_post_meta($post->ID,'show_heading',true) == 'yes') { ?>
				<div class="col-md-8">
					<h3 class="site-title"><?php the_title(); ?></h3>
					<div class="row spacer20"></div>
					
				</div>
				<div class="col-md-4">
					<?php if(get_post_meta($post->ID,'show_breadcrumb',true) == 'yes') { ?>
						<?php if(function_exists('bcn_display'))
					    {
					    	echo '<ul class="breadcrumb">';
					        bcn_display();
					        echo '</ul>';
					    }?>
					<?php } ?>
				</div>
			<?php } ?>
			</div>
		</div>
		<?php get_template_part( 'content', 'page' ); ?>
		<?php if (comments_open($post->ID)){ ?>
			<div class="container">
				<?php comments_template( '', true ); ?>
			</div>
		<?php } ?>
	<?php endwhile; // end of the loop. ?>
				
		

<?php get_footer(); ?>