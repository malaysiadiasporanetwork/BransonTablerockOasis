<?php
global $entiri_opt;
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 */
?>
        
        
    </section>
    
    <!-- Footer -->
    <?php //print_r($entiri_opt); ?>
    <footer>
      <div class="container">    
        <div class="row footer">
          <div class="col-md-12">          
            <div class="row">
              <div class="col-sm-4">
                <?php echo $entiri_opt['footer-text']; ?>
              </div> 
                          
              <div class="col-sm-4 address-box">
                
                <h4><?php _e($entiri_opt['footer-address-heading'], 'reno'); ?></h4>
                <?php echo $entiri_opt['footer-address-text']; ?>
              </div>
              <div class="col-sm-4 contact-box">
                <h4><?php _e($entiri_opt['footer-contact-heading'], 'reno'); ?></h4>
                <?php echo $entiri_opt['footer-phone']; ?>
                <?php echo $entiri_opt['footer-web']; ?>
              </div>    
            </div>      
          </div>
        </div>

        <div class="row after-footer">
          <div class="col-md-4"><p><strong><?php echo $entiri_opt['footer-copyright']; ?></strong></p></div>
          <div class="col-md-4"><p><?php echo $entiri_opt['footer-site-info']; ?></p></div>
          <div class="col-md-4">
          <p>
            <?php echo reno_social_icons_display(); ?>                      
          </p>
          </div>
        </div>      
      </div> 
    </footer>
    <!-- Footer End -->
    <?php 
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    if (!is_plugin_active('ubermenu/ubermenu.php')) {
      reno_mobile_menu_script();
    }
    ?>
<?php wp_footer(); ?>
</body>
</html>