<?php
function reno_load_required() {

	

	if(!get_option('reno_homepage')) {
		$home = wp_insert_post(array(
		    'post_title'    => 'Home',
		    'post_type' 	=> 'page',
		    'post_content'  => '',
		    'post_status'   => 'publish',
		    'post_author'   => 1
		));
		update_post_meta($home,'_wp_page_template','page-templates/front-page.php');
		update_option( 'page_on_front', $home );
		update_option( 'show_on_front', 'page' );
		update_option('reno_homepage', $home);

	}
	

	/* load categories */
	if(!get_option('reno_portfolio_cat')) {

		$portfolio = wp_insert_term(
		    'reno portfolio', 
		    'category', 
		    array(
		        'parent'=> 0
		    )
		);
		update_option('reno_portfolio_cat', $portfolio['term_id']);

		$portfolio_post = wp_insert_post(array(
		   'post_title'    => '1',
		   'post_type' 	   => 'portfolio',
		   'post_content'  => '',
		   'post_status'   => 'publish',
		   'post_author'   => 1
		));

		wp_set_post_categories( $portfolio_post, array($portfolio['term_id']) );
		
		$architecture = wp_insert_term(
		    'Architecture', // the term
		    'category', // the taxonomy
		    array(
		        'parent'=> $portfolio['term_id']
		    )
		);
		
		$webdesign = wp_insert_term(
		    'Webdesign', // the term
		    'category', // the taxonomy
		    array(
		        'parent'=> $portfolio['term_id']
		    )
		);

		
		$technology = wp_insert_term(
		    'Technology', // the term
		    'category', // the taxonomy
		    array(
		        'parent'=> $portfolio['term_id']
		    )
		);

		
		$photography = wp_insert_term(
		    'Consulting', // the term
		    'category', // the taxonomy
		    array(
		        'parent'=> $portfolio['term_id']
		    )
		);

		
		$identity = wp_insert_term(
		    'Identity', // the term
		    'category', // the taxonomy
		    array(
		        'parent'=> $portfolio['term_id']
		    )
		);

		
	}

	delete_option("category_children");

}
add_action("after_switch_theme", "reno_load_required", 10 ,  2);
?>