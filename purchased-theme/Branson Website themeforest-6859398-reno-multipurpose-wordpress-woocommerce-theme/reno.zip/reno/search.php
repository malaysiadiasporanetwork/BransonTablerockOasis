<?php
/**
 * The template for displaying Search Results pages.
 */

get_header(); ?>

	<div class="container">
		<div class="row spacer40"></div>
	      <div class="row">
	        <div class="col-md-8">
	          <h3><?php _e('Search results' ,'reno'); ?></h3>
	        </div>
	        <div class="col-md-4">
	          <?php if(function_exists('bcn_display'))
			    {
			    	echo '<ul class="breadcrumb">';
			        bcn_display();
			        echo '</ul>';
			    } ?>
	        </div>      
	      </div>
	      <div class="row spacer20"></div>
		<?php
		if($entiri_opt['blog-template'] == 'left_sidebar' || (isset($_GET['template']) && $_GET['template'] == 'left_sidebar')) { 
			load_template(TEMPLATEPATH . '/blog-left_sidebar.php');
		}
		
		elseif ($entiri_opt['blog-template'] == 'full_width'  || (isset($_GET['template']) && $_GET['template'] == 'full_width')) {
			load_template(TEMPLATEPATH . '/blog-full_width.php');
		}
		elseif ($entiri_opt['blog-template'] == 'right_sidebar'  || (isset($_GET['template']) && $_GET['template'] == 'right_sidebar')) {
			load_template(TEMPLATEPATH . '/blog-right_sidebar.php');
		}
		?>
		<?php 
			reno_content_nav( 'nav-below' );
		?>
	</div>


<?php get_footer(); ?>